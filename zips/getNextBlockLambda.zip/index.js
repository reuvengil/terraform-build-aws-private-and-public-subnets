import mongoose from "mongoose"
import axios from "axios";
export const handler = async (event, context) => {
    console.log(await axios.get("https://www.google.com"));
    return {
      statusCode: 200,
      body: JSON.stringify("Omrikuh"),
    };
  };
