import axios from "axios";

import { Logger } from '@aws-lambda-powertools/logger';

const logger = new Logger({ serviceName: 'serverlessHealthcheck' });

export const handler = async (event, context) => {
  let response;
  try {
    response = await axios.get("https://www.google.com")
    if (response && response.status) {
      logger.info(`status: ${response.status}`)
    }
  } catch (err) {
    if (err.response && err.response.status) {
      logger.info(`status: ${response.status}`)
    } else {
      logger.info(`err: ${err}`)
    }
  }
  const status = response?.status === undefined ? 'time out' : response?.status

  return {
    statusCode: status,
    error: status === 'time out' || status >= 400,
  };
};
